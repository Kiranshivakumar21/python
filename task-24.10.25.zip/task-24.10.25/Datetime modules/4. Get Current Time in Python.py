from datetime import datetime

now = datetime.now()
print("Current Time:", now.time())
