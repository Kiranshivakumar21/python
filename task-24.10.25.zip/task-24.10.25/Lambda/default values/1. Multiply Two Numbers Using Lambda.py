# Lambda function to multiply x and y
multiply = lambda x, y: x * y
result = multiply(5, 7)
print("Multiplication Result:", result)
