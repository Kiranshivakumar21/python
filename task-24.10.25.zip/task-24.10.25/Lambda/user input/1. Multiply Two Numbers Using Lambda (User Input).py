# Get user input for x and y
x = int(input("Enter first number (x): "))
y = int(input("Enter second number (y): "))
multiply = lambda a, b: a * b
result = multiply(x, y)
print("Multiplication Result:", result)
