# Inverse Right Triangle
rows = 6
for i in range(1, rows + 1):
  print(' ' * (i - 1) + '*' * (rows - i + 1))
