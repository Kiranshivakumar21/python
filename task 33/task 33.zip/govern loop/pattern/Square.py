# Square
size = 5
for _ in range(size):
    print('*' * size)
