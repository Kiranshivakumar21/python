# Right Triangle
rows = 5
for i in range(1, rows + 1):
    print('*' * i)
