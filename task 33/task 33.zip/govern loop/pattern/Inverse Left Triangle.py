# Inverse Left Triangle
rows = 6
for i in range(rows, 0, -1):
    print(' ' * (rows - i) + '*' * i)
