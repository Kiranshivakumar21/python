nums = [float(input("Enter number: ")) for _ in range(3)]
nums.sort()
print("Median is:", nums[1])
