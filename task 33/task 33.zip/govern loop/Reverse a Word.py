def reverse_word_loop():
     word = (input("Enter a word: "))
     reversed_word = ""
     for char in word:
         reversed_word = char + reversed_word
     print(f"Reversed word: {reversed_word}")
reverse_word_loop()
