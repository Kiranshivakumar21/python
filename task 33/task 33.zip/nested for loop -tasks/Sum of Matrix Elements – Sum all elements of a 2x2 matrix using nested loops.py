matrix = [[1,2],[3,4]]
total_sum = 0
for i in range (2):
   for j in range(2):
          total_sum += matrix[i][j]
print(f"total sum = {total_sum}")
